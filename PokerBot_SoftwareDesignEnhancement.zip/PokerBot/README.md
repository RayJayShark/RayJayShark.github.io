# PokerBot
A discord bot to play texas hold'em with your friends!

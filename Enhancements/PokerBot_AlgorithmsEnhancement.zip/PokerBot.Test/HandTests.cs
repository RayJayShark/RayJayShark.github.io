using System;
using System.Collections.Generic;
using PokerBot.Classes;
using Xunit;

namespace PokerBot.Test
{
    public class HandTests
    {
        [Theory]
        [InlineData("c14,c10,c11,c12,c13", 9, 0, 0, 0, "A Royal Flush")]  
        [InlineData("c2,c3,c4,c5,c6", 8, 6, 0, 0, "A Straight Flush")]    
        [InlineData("c3,s3,d3,h3,c6", 7, 3, 6, 0, "Four of a Kind")]    
        [InlineData("c3,s3,d10,h3,c10", 6, 3, 10, 0, "A Full House")]     
        [InlineData("c2,c3,c10,c5,c6", 5, 10, 0, 0, "A Flush")]           
        [InlineData("c2,c3,c4,d5,c6", 4, 6, 0, 0, "A Straight")]          
        [InlineData("c14,c2,c3,d4,c5", 4, 14, 0, 0, "A Straight")]        //Ace-High Straight
        [InlineData("c3,d3,s3,c5,c6", 3, 3, 6, 0, "Three of a Kind")]   
        [InlineData("c2,s2,c10,c5,s5", 2, 5, 2, 10, "Two Pair")]        
        [InlineData("s3,c3,c10,d7,c6", 1, 3, 10, 0, "A Pair")]            
        [InlineData("c2,c3,s10,c5,c6", 0, 10, 0, 0, "High Card")]       
        public void CalculateScoreTest(string cards, int expScoreOne, int expScoreTwo, int expScoreThree, int expScoreFour, string expName)
        {
            var cardStrings = cards.Split(',');
            var cardList = new List<Card>();
            foreach (var cardString in cardStrings)
            {
                cardList.Add(new Card(
                    cardString.Substring(0,1),
                    int.Parse(cardString.Substring(1))));
            }

            var hand = new Hand(cardList);
            Assert.True(hand.GetScoreOne() == expScoreOne, $"Score One Incorrect\nExp Score: {expScoreOne}\nActual Score: {hand.GetScoreOne()}");
            Assert.True(hand.GetScoreTwo() == expScoreTwo, $"Score Two Incorrect\nExp Score: {expScoreTwo}\nActual Score: {hand.GetScoreTwo()}");
            Assert.True(hand.GetScoreThree() == expScoreThree, $"Score Three Incorrect\nExp Score: {expScoreThree}\nActual Score: {hand.GetScoreThree()}");
            Assert.True(hand.GetScoreFour() == expScoreFour, $"Score Four Incorrect\nExp Score: {expScoreFour}\nActual Score: {hand.GetScoreFour()}");
            Assert.True(hand.GetHandName() == expName, $"Hand name incorrect:\nExp Name: {expName}\nActual Name: {hand.GetHandName()}");
        }
    }
}